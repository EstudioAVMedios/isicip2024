var email_active;
$(".fact_data").click(function () {
    email_active = $(this).prevAll('p').text();
console.log(email_active);
    $.ajax({
        url: "php/user_fact.php",
        type: "POST",
        data: "id=" + email_active + "&edit=no",
        success: function (res) {
            var data = jQuery.parseJSON(res);

            $("#nif_modal").text(data.NIF);
            $("#rs_modal").text(data.RAZON_S);
            $("#bill_modal").text(data.BILL_ADDRESS);
            $("#prov_modal").text(data.PROVINCIA);
            $("#pobla_modal").text(data.POBLACION);
            $("#email_modal").text(data.EMAIL_FACT);
            $("#cp_modal").text(data.C_POSTAL);
            $("#tel_modal").text(data.TEL_FACT);

        }

    })

})
$(".activar").click(function () {
    email_active = $(this).closest("td").prevAll('.email').text();
    $("#modal_email").text($(this).closest("td").prevAll('.email').text());
})
$("#send_active").click(function () {

    $.ajax({
        url: "php/user_active.php",
        type: "POST",
        data: "id=" + email_active,
        success: function (res) {
            if ($.trim(res) == "success") {
                location.reload();
            }
       

        }
    })
})

var email_id_delete;
$(".icon-burn").click(function () {

    email_id_delete = $(this).closest("td").prevAll('.email').text();
    $("#modal_delete").text($(this).closest("td").prevAll('.email').text());

})


$("#send_delete").click(function () {

    $.ajax({
        url: "php/user_delete.php",
        type: "POST",
        data: "id=" + email_id_delete,
        success: function (res) {
            if ($.trim(res) == "success") {
                location.reload();
            }

        }
    })

})
/*href="<?php echo $_SESSION['PHP_SELF'].'?export=true'?>"*/
$(document).ready(function () {


    var boolean = true;
    $("#show").on("click", function () {
        if (boolean == true) {
            $("#exampleFormControlInput1").attr("type", "text");
            $(this).text("Ocultar");
            boolean = false;
        } else {
            $("#exampleFormControlInput1").attr("type", "password");
            $(this).text("Mostrar");
            boolean = true;
        }

    })


});

$(document).ready(function () {
    irArriba();
}); //Hacia arriba

function irArriba() {
    $('.ir-arriba').click(function () {
        $('body,html').animate({
            scrollTop: '0px'
        }, 500);
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 0) {
            $('.ir-arriba').slideDown(500);
        } else {
            $('.ir-arriba').slideUp(500);
        }
    });
    $('.ir-abajo').click(function () {
        $('body,html').animate({
            scrollTop: '1000px'
        }, 500);
    });
}


$('#sendfilter').click(function () {
    var filterdata = new FormData(document.getElementById('form_filter'));
    $('#form_filter input[type=checkbox]').each(function () {
        if (this.checked) {
            filterdata.append("filtro[]", $(this).next('label').text());
        }
    });
    $.ajax({
        url: "php/filter.php",
        type: "POST",
        cache: false,
        data: filterdata,
        contentType: false,
        processData: false,
        success: function (res) {

            if ($.trim(res) == "ok") {
                location.reload();
            }
        }
    })

});


$(".form-check-label").on("click", function () {
    return false;
})


$('.js-nav').click(function () {
    $(this).parent().find('.menu').toggleClass('active');
});


$("#subir_excel").click(function () {
    if ($("#radio1").prop('checked') == true) {

        var importar = new FormData(document.getElementById('import-form'));
        $.ajax({
            url: "php/importfile.php",
            type: "POST",
            cache: false,
            data: importar,
            contentType: false,
            processData: false,
            success: function (res) {
console.log(res);
                //location.reload();

            }
        })
    } else {
        var importar = new FormData(document.getElementById('import-form'));
        $.ajax({
            url: "php/importfileact.php",
            type: "POST",
            cache: false,
            data: importar,
            contentType: false,
            processData: false,
            success: function (res) {

      console.log(res);

            }
        })
    }


})


$(".export").click(function () {
    $('body').removeClass('modal-open');
    $("#staticBackdrop2").modal('hide');
    $('.modal-backdrop').remove();
})

function out_modal() {
    
    const myModalEl = document.getElementById('staticBackdrop2')
    myModalEl.addEventListener('hidden.bs.modal', event => {
        // do something...
    })
}


var toogle2 = true;

$("#show").click(function () {

    if (toogle2 == true) {

        $("#pass").attr("type", "text");

        $(this).text("Ocultar");

        toogle2 = false;

    } else {

        $("#pass").attr("type", "password");

        $(this).text("Mostrar");

        toogle2 = true;

    }

})

var toogle3 = true;

$("#show1").click(function () {

    if (toogle3 == true) {

        $("#pass1").attr("type", "text");

        $(this).text("Ocultar");

        toogle3 = false;

    } else {

        $("#pass1").attr("type", "password");

        $(this).text("Mostrar");

        toogle3 = true;

    }


})


var mpago = false;
$(".m-pago").click(function () {

    $('.m-pago-check').removeClass('m-pago-check').addClass('m-pago');
    $(this).removeClass('m-pago').addClass('m-pago-check');
    mpago = $(this).find('p').text();

    if (mpago == "bank") {
        $('#bankdata').slideDown();
    } else {
        $('#bankdata').slideUp();
    }
})

var mpago2 = false;
$(".m-pago2").click(function () {

    $('.m-pago2-check').removeClass('m-pago2-check').addClass('m-pago2');
    $(this).removeClass('m-pago2').addClass('m-pago2-check');
    mpago2 = $(this).find('p').text();

    if (mpago2 == "bank") {
        $('#bankdata').slideDown();
    } else {
        $('#bankdata').slideUp();
    }
    if (mpago2 == 2) {
        $('#socsec').fadeIn().addClass('required text');

    } else {
        $('#socsec').fadeOut().removeClass('required text');
    }
})


$(function () {

    var v = $("#contactform").validate({

        submitHandler: function (form) {
            if (mpago != false && mpago2 != false) {
                if ($("#pass").val() != "" && $("#pass1").val() != "" && $("#pass").val() === $("#pass1").val()) {

                    if ($("#type").text() != 3) {

                        $(function () {


                            validate($("#dni").val());

                        })

                        return false;

                    } else {

                        enviar();


                    }

                } else {

                    $("#formalert").append("<p class='bg-blue-2 text-center p-2'>!Lo Sentimos, las contraseñas no coinciden.</p>");

                }
            } else {
                $("#formalert").append("<p class='bg-blue-2 text-center p-2'>!Lo Sentimos, Debe seleccionar su método de pago y la cuota.</p>");

            }

        }

    });

});

//To clear message field on page refresh (you may clear other fields too, just give the 'id to input field' in html and mention it here, as below)

$('#contactform #message').val('');


function enviar() {

    var datos = new FormData(document.getElementById('contactform'));

    datos.append("type", mpago2);
    datos.append("ip", $("#ip").text());
    datos.append("pais", $("#pais").text());
    datos.append("pay", mpago);
    $.ajax({

        url: "../php/contact-form.php",

        /*target: "#result",*/

        clearForm: true,

        data: datos,

        contentType: false,

        processData: false,

        type: "POST",

        success: function (res) {

            if ($.trim(res) == "ok") {

                location.reload();

            } else if ($.trim(res) == "full") {

                $("#formalert").append("<p class='bg-blue-2 text-center p-2'>!Lo Sentimos, existe un registro con el email que intenta registrar.</p>");

            }

         

        }


    });

    return false;

}


function validate(value) {

    var validChars = 'TRWAGMYFPDXBNJZSQVHLCKET';

    var nifRexp = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;

    var nieRexp = /^[XYZ]{1}[0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;

    var str = value.toUpperCase();

    var nie = str

        .replace(/^[X]/, '0')

        .replace(/^[Y]/, '1')

        .replace(/^[Z]/, '2');


    var letter = str.substr(-1);

    var charIndex = parseInt(nie.substr(0, 8)) % 23;


    if (!nifRexp.test(str) && !nieRexp.test(str)) $("#formalert").append("<p class='bg-blue-2 text-center p-2'>!Lo Sentimos, debe introducir un documento válido.</p>");

    if (validChars.charAt(charIndex) === letter) enviar();


    return false;

}


var email2;
var id2;
var id3;
$(".edit").click(function () {
    email2 = $(this).closest("td").prevAll('.email').text();
	id3=$(this).prev("p").text();
	
   $.ajax({
        url: "php/user_fact.php",
        type: "POST",
        data: "id=" + id3 + "&edit=true",
        success: function (res) {
			
            var data = jQuery.parseJSON(res);
            id2 = data.ID;
            $("#nom").val(data.NAME);
            $("#ape2").val(data.SURNAME);
            $("#dni2").val(data.DNI);
            $("#email2").val(data.EMAIL);
            $("#sec2").val(data.SEC);
            $("#ctrab").val(data.C_TRABAJO);
            $("#espe").val(data.ESPECIALIDAD);
            $("#charge").val(data.CARGO);
            $("#tele").val(data.TEL);

            $(".m-pago2-check").addClass('m-pago2').removeClass('m-pago2-check');
            $(".m-pago-check").addClass('m-pago').removeClass('m-pago-check');

            $("#cif").val(data.NIF);
            $("#rsocial").val(data.RAZON_S);
            $("#address").val(data.BILL_ADDRESS);
            $("#cpostal").val(data.C_POSTAL);
            $("#pobla").val(data.POBLACION);
            $("#prov").val(data.PROVINCIA);
            $("#email3").val(data.EMAIL_FACT);
            $("#tele2").val(data.TEL_FACT);

            if (data.TYPE == 1) {
                $("#cuota1").addClass('m-pago2-check').removeClass('m-pago2');
            } else if (data.TYPE == 2) {
                $("#cuota2").addClass('m-pago2-check').removeClass('m-pago2');
            } else if (data.TYPE == 3) {
                $("#cuota3").addClass('m-pago2-check').removeClass('m-pago2');
            }else if (data.TYPE == 4) {
                $("#cuota4").addClass('m-pago2-check').removeClass('m-pago2');
            }else if (data.TYPE == 5) {
                $("#cuota5").addClass('m-pago2-check').removeClass('m-pago2');
            }else if (data.TYPE == 6) {
                $("#cuota6").addClass('m-pago2-check').removeClass('m-pago2');
            }


            if (data.F_PAGO == "bank") {
                $("#banco").addClass('m-pago-check').removeClass('m-pago');
            } else {
                $("#tarjeta").addClass('m-pago-check').removeClass('m-pago');
            }
			
        }


    })


})
$('#update').click(function(){
  enviar2();
   return false;		
		
})

function enviar2() {

    var datos = new FormData(document.getElementById('contactform2'));

    datos.append("type", mpago2);
    datos.append("ip", $("#ip").text());
    datos.append("pais", $("#pais").text());
    datos.append("pay", mpago);
	datos.append("elid", id3);
    $.ajax({

        url: "../php/contact-form-update.php",

        /*target: "#result",*/

        clearForm: true,

        data: datos,

        contentType: false,

        processData: false,

        type: "POST",

        success: function (res) {
		console.log(res);	

            if ($.trim(res) == "ok") {

                 location.reload();

            } else if ($.trim(res) == "full") {

                $("#formalert2").append("<p class='bg-blue-2 text-center p-2'>!Lo Sentimos, existe un registro con el email que intenta registrar.</p>");

            }

      

        }


    });

    return false;

}