<?php 

include('../../connect/config.php');



$name=$_POST['patrocinador'];

$fondo=$_POST['fondo_patrocinador'];



$sql="DELETE FROM sponsors WHERE NAME= :name";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":name"=>$name));



$sql4="SELECT * FROM sponsors";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$patrocinadores[]=$fila4;

};



unlink('../../Imagenes/patrocinadores/'.$name.'.png');

unlink('../../Imagenes/patrocinadores/'.$name.'.png');

	

$file='../../info/patrocinio.json';

file_put_contents($file,json_encode($patrocinadores));





echo "success";



?>