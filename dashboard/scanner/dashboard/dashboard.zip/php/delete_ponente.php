<?php 

include('../../connect/config.php');



$email=$_POST['email_p'];



$sql="DELETE FROM ponentes WHERE EMAIL= :email";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":email"=>$email));



$sql4="SELECT * FROM ponentes ORDER BY LASTNAME ASC";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$ponentes[]=$fila4;

};



unlink('../../Imagenes/ponentes/'.base64_encode($email).'.png');

	

$file='../../info/ponentes.json';

file_put_contents($file,json_encode($ponentes));





echo "success";



?>