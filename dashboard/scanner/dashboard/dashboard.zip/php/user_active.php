<?php


if ( $_POST ) {


    include( "../../php/config.php" );
    require( "../../php/SMTP/class.phpmailer.php" );
    require( "../../php/SMTP/class.smtp.php" );

    $email = $_POST[ 'id' ];


    $sql2 = "UPDATE form SET STATE=:status WHERE EMAIL= :email";

    $resultado2 = $cnt->prepare( $sql2 );

    $resultado2->execute( array( ":status" => 1, ":email" => $email ) );

    $sql3 = 'SELECT *FROM form WHERE EMAIL=:email';
    $resultado3 = $cnt->prepare( $sql3 );
    $resultado3->execute( array( ":email" => $email ) );
    $fila3 = $resultado3->fetch( PDO::FETCH_ASSOC );


    //*********************************************************Mail***************************************************************************//
    if ( $fila3[ 'TYPE' ] == 1 ) {
        $tipo = "Cuota general";
        $cost = "280,00€";
    } elseif ( $fila3[ 'TYPE' ] == 2 ) {
        $tipo = "Cuota socio SEC";
        $cost = "190,00€";
    } else {
        $tipo = "Cuota online";
        $cost = "120,00€";
    }


    $para = $email;
    $titulo = "CONFIRMACION DE INSCRIPCION";
    $mensaje = "<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<title>Curso Residentes Obesidad</title>
	<style>
		*{
			margin: auto;
			text-align: center;
		}
		p{
		color:black;
		}
		p strong{
		color:black;
		}
	</style>
</head>
<body>
<div style='width: 100%; height: 100%; background: #E9E9E9;margin:auto;text-align:center'>
	<table style='background: white; width: 600px;margin: auto; font-family: Arial, sans-serif;font-size: 14px;' cellpadding='0' cellspacing='0'>
		<tbody style='text-align:left'>
			<tr><td colspan='3'>
	<img src='https://fa-madrid.com/assets/images/mail/header.png' style='width: 600px' height='295px'>
				</td></tr>
			<tr style='height: 30px;'><td></td><td></td><td></td></tr>
			<tr><td style='width: 60px;'></td>
			
				<td style='width: 500px;'>
				
				<h3 style='color:#0A4F87; text-align: left!important; padding: 20px 0px'>Estimado/a " . $fila3[ 'NAME' ] . " " . $fila3[ 'SURNAME' ] . "</h3>
					<p style='text-align: left!important; color: black'>Le confirmamos su inscripción al X Simposio Científico FA Madrid FAM 2022, que se celebrará en el Hospital General La Paz de Madrid, los días 26 y 27 de septiembre de 2022.<br><br> Los detalles de su inscripción son los siguientes:<br><strong>ID:</strong> " . $fila3[ 'ID' ] . "<br><strong>Cuota inscripción:</strong> " . $tipo . "<br><strong>Importe total:</strong> " . $cost . "<br><br></p>
					</td>
					<td style='width: 40px;'></td></tr>
					
					
					
<tr><td style='text-align: left;vertical-align: bottom'><img src='https://fa-madrid.com/assets/images/mail/hag.png' width='60px' height='140px'></td><td>
					<br><p style='text-align: left!important;'>Para acceder al <strong>AREA PERSONAL</strong> debe hacerlo con sus credenciales:</p>
		
					<p style='text-align: left!important; '><strong>Acceso Area Personal: </strong><a href='https://www.fa-madrid.com/'>Pincha aquí</a></p>
					<p style='text-align: left!important; '><strong>Correo electrónico: </strong><span>" . $email . "</span></p>
					<p style='text-align: left!important; '><strong>Contraseña: </strong><span> Cumpliendo con el Reglamento UE 679/2016, de 27 de abril, General de Protección de Datos, y con la Ley Orgánica 3/2018, de Protección de Datos Personales y Garantía de los Derechos Digitales, no tenemos acceso a su contraseña. Si no la recuerda puede recuperarla pulsando en <a href='https://fa-madrid.com/'>He olvidado mi contraseña.</span></a></p><br>
					<p style='text-align: left!important; '>Si desea ponerse en contacto con nosotros puede hacerlo escribiendo a <a href='mailto:fam@win2wingroup.es'><strong style='color: #0A4F87'>fam@win2wingroup.es</strong></a><br><br>
					Si presenta alguna dificultad técnica escríbanos a <a href='mailto:fam@avstreaming.es'><strong style='color: #0A4F87'>fam@avstreaming.es</strong></a><br><br>
				
					Un cordial Saludo,<br><br>
					</p>
				
				</td><td style='width: 40px'></td></tr>
					
			
		<tr><td colspan='3'><img src='https://fa-madrid.com/assets/images/mail/footer.png' width='600px' height='100px'></td></tr>				
			</tr>
			
		</tbody>
	</table>
</div>
</body>
</html>";

    $cabeceras = 'From: noreply@avstreaming.es' . "\r\n" .
    'Reply-To: noreply@avstreaming.es' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    $cabeceras .= 'MIME-Version: 1.0' . "\r\n";
    $cabeceras .= 'Content-type: text/html; charset=utf-8' . "\r\n";

    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->Port = 587;
    $mail->IsHTML( true );
    $mail->CharSet = "utf-8";

    // VALORES A MODIFICAR //
    $mail->Host = $smtpHost;
    $mail->Username = $smtpUsuario;
    $mail->Password = $smtpClave;


    // Datos de la cuenta de correo utilizada para enviar vía SMTP
    $smtpHost = "mail.avstreaming.es"; // Dominio alternativo brindado en el email de alta 
    $smtpUsuario = "noreply@avstreaming.es"; // Mi cuenta de correo
    $smtpClave = "NoPlyStreaming20"; // Mi contraseña

    $mail->From = "noreply@avstreaming.es"; // Email desde donde envío el correo.
    $mail->FromName = $nombre;
    $mail->AddAddress( $para ); // Esta es la dirección a donde enviamos los datos del formulario

    $mail->Subject = "REGISTRO ACTIVADO"; // Este es el titulo del email.
    $mensajeHtml = $mensaje;
    $mail->Body = "";

    // Texto del email en formato HTML
    $mail->AltBody = "{$mensaje} \n\n "; // Texto sin formato HTML
    // FIN - VALORES A MODIFICAR //

    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    $estadoEnvio = $mail->Send();


    mail( $para, $titulo, $mensajeHtml, $cabeceras );


    echo "success";


}


?>