<?php 

include('../../connect/config.php');



$video=$_POST['video'];



$sql="DELETE FROM video WHERE TITLE= :video";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":video"=>$video));



$sql4="SELECT * FROM video";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$videos[]=$fila4;

};



unlink('../../Imagenes/videos/miniaturas/'.base64_encode($video).'.png');

	

$file='../../info/videos_carta.json';

file_put_contents($file,json_encode($videos));





echo "success";



?>