<?php


if ( $_POST ) {


    include( "../../php/config.php" );


    $id = $_POST[ 'id' ];

    if ( $_POST[ 'edit' ] == "no" ) {


        $sql3 = 'SELECT * FROM form2 WHERE USER_ID=:id';
        $resultado3 = $cnt->prepare( $sql3 );
        $resultado3->execute( array( ":id" => $id ) );
        $fila3 = $resultado3->fetch( PDO::FETCH_ASSOC );

        $datos = json_encode( $fila3 );

        echo $datos;


    } else {


        $sql = 'SELECT * FROM form WHERE ID=:id';
        $resultado = $cnt->prepare( $sql );
        $resultado->execute( array( ":id" => $id ) );
        $fila = $resultado->fetch( PDO::FETCH_ASSOC );

        $datos = $fila;

        if ( $fila[ 'IMPORT' ] == 0 ) {

            $sql3 = 'SELECT * FROM form2 WHERE USER_ID=:id';
            $resultado3 = $cnt->prepare( $sql3 );
            $resultado3->execute( array( ":id" => $id ) );
            $fila3 = $resultado3->fetch( PDO::FETCH_ASSOC );
            $datos2 = $fila3;
            $datos3 = array_merge( $datos, $datos2 );
            $datos4 = json_encode( $datos3 );

            echo $datos4;

        } else {
            $datos4 = json_encode( $datos );
			            echo $datos4;
        }
    }
} else {
    echo "no";
}


?>