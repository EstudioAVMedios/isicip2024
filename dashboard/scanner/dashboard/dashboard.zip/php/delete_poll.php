<?php

include('../../connect/config.php');



$poll=$_POST['poll'];

$polls=[];

$sql="DELETE FROM poll WHERE POLL= :poll";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":poll"=>$poll));



$sql4="SELECT * FROM poll";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$polls[]=$fila4;

};



$file='../../info/poll.json';

file_put_contents($file,json_encode($polls));





echo "success";



?>

