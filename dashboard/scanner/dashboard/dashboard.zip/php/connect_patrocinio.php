<?php 



include("../../connect/config.php");



$name=$_POST['empresa_patrocinio'];

$url=$_POST['url_patrocinio'];

$type=$_POST['type_patrocinio'];

$info=$_POST['info_patrocinio'];

$linkedin=$_POST['linkedin_patrocinio'];

$email=$_POST['email_patrocinio'];

$phone=$_POST['phone_patrocinio'];

$video=$_POST['video_patrocinio'];
$contact_name=$_POST['contact_patrocinio'];


$sql2="SELECT * FROM sponsors WHERE NAME = :name AND TYPE= :type";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":name"=>$name, ":type"=>$type));

$fila=$resultado2->rowCount();

$fila2=$resultado2->fetch(PDO::FETCH_ASSOC);







if($_FILES['logo_patrocinio']){

	

$logo_name=$name.".png";

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/patrocinadores/";

move_uploaded_file($_FILES['logo_patrocinio']['tmp_name'],$ruta.$logo_name);

$logo=$logo_name;

	

}else if($fila2['LOGO']==$name.".png"){

	$logo=$fila2['LOGO'];

}else{

$logo=NULL;	

}



if($_FILES['fondo_patrocinio']){

	

$fondo_name="fondo_". $name.".png";

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/patrocinadores/";

move_uploaded_file($_FILES['fondo_patrocinio']['tmp_name'],$ruta.$fondo_name);

$fondo=$fondo_name;

	

}else if($fila2['FONDO']==$name.".png"){

	$fondo=$fila2['FONDO'];

}else{

$fondo=NULL;	

}



if($_FILES['archivo_patrocinio']){

	

$archivo_name=base64_encode($_FILES['archivo_patrocinio']['tmp_name']).".pdf";

$ruta=$_SERVER['DOCUMENT_ROOT']."/info/archivos/";

move_uploaded_file($_FILES['archivo_patrocinio']['tmp_name'],$ruta.$archivo_name);

$archivo=$archivo_name;	

	

}else if($fila2['FILE']==$name.".pdf"){

	$archivo=$fila2['FILE'];

}else{

$archivo=NULL;	

}

if($_FILES['archivo2_patrocinio']){

	

$archivo_name=base64_encode($_FILES['archivo2_patrocinio']['tmp_name']).".pdf";

$ruta=$_SERVER['DOCUMENT_ROOT']."/info/archivos/";

move_uploaded_file($_FILES['archivo2_patrocinio']['tmp_name'],$ruta.$archivo_name);

$archivo2=$archivo_name;	

	

}else if($fila2['FILE2']==$name.".pdf"){

	$archivo2=$fila2['FILE2'];

}else{

$archivo2=NULL;	

}



if($fila!=0){

	

$sql3='DELETE FROM sponsors WHERE NAME =:name';

$resultado3=$cnt->prepare($sql3);

$resultado3->execute(array(":name"=>$name));







$sql="INSERT INTO sponsors (NAME,URL, INFO, TYPE, LINKEDIN, EMAIL, PHONE, VIDEO, FONDO, FILE, LOGO, FILE2,CONTACTNAME) VALUES (:name, :url, :info, :type,:linkedin,:email, :phone, :video, :fondo, :file,:logo,:file2,:cname)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":name"=>$name, ":url"=>$url, ":info"=>$info, ":type"=>$type, ":linkedin"=>$linkedin, ":email"=>$email, ":phone"=>$phone, ":video"=>$video, ":fondo"=>$fondo,":file"=>$archivo,":logo"=>$logo, ":file2"=>$archivo2,":cname"=>$contact_name));







}else{



	

$sql="INSERT INTO sponsors (NAME,URL, INFO, TYPE, LINKEDIN, EMAIL, PHONE, VIDEO, FONDO, FILE, LOGO, FILE2,CONTACTNAME) VALUES (:name, :url, :info, :type,:linkedin,:email, :phone, :video, :fondo, :file,:logo,:file2,:cname)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":name"=>$name, ":url"=>$url, ":info"=>$info, ":type"=>$type, ":linkedin"=>$linkedin, ":email"=>$email, ":phone"=>$phone, ":video"=>$video, ":fondo"=>$fondo,":file"=>$archivo,":logo"=>$logo, ":file2"=>$archivo2,":cname"=>$contact_name));



	

}

$patrocinio=[];

ordenar_lista("Gold");

ordenar_lista("Silver");

ordenar_lista("Bronze");

ordenar_lista("Colaborador");





function ordenar_lista($e){

global $patrocinio;

global $cnt;

$sql4="SELECT * FROM sponsors WHERE TYPE=:type ORDER BY NAME ASC";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute(array(":type"=>$e));

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$patrocinio[]=$fila4;

};

	

}



$file='../../info/patrocinio.json';

file_put_contents($file,json_encode($patrocinio));



if($fila!=0){

	echo "encontrado";

}else{

echo "succes";	

}



?>