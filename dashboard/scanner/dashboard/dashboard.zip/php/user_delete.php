<?php

include( "../../php/config.php" );
if ( $_POST ) {
$id=$_POST['id'];

  $sql2 = 'DELETE FROM form WHERE EMAIL=:id';
  $resultado2 = $cnt->prepare( $sql2 );
  $resultado2->execute( array( ":id" => $id ) );
  echo "success";
}else{
	echo "Intenta entrar de una forma no permitida";
}


?>