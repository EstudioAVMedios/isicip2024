<?php 



include("../../connect/config.php");



$name=$_POST['nombre_p'];

$lastname=$_POST['apellidos_p'];

$company=$_POST['empresa_p'];

$country=$_POST['pais_p'];

$charge=$_POST['cargo_p'];

$bio=$_POST['bio_p'];

$linkedin=$_POST['linkedin_p'];

$email=$_POST['email_p'];

$rol=$_POST['rol_p'];

$title=$_POST['titulo_p'];

$ctype=$_POST['comitetype_p'];
	
$ponentes=[];





$sql2="SELECT * FROM ponentes WHERE EMAIL = :email";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":email"=>$email));

$fila=$resultado2->rowCount();

$fila2=$resultado2->fetch(PDO::FETCH_ASSOC);



$programa=$_POST['programa'];



if($_FILES['foto_p']){

	

$ponente=base64_encode($email).".png";

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/ponentes/";

move_uploaded_file($_FILES['foto_p']['tmp_name'],$ruta.$ponente);

	

}else if($fila2['IMG']==base64_encode($email).".png"){

	$ponente=$fila2['IMG'];

}else{

$ponente="user.png";	

}



if($fila!=0){

	

$sql3='DELETE FROM ponentes WHERE EMAIL =:email';

$resultado3=$cnt->prepare($sql3);

$resultado3->execute(array(":email"=>$email));


if($programa!=""){

foreach($programa as $elemento){

	

	$porciones = explode(",", $elemento);
if($bio==""){
$bio=$fila2['BIO'];	
}



$sql="INSERT INTO ponentes (TITLENAME, NAME, LASTNAME, CHARGE, COMPANY, BIO, IMG, COUNTRY, LINKEDIN, EMAIL, DATE, PROGRAMA, ROL, DATE_PROGRAM, COMMITTEETYPE) VALUES (:title,:name, :last, :charge, :company, :bio, :img, :country, :linkedin, :email, :date,:prog, :rol, :dateprog, :ctype)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":title"=>$title, ":name"=>$name, ":last"=>$lastname, ":charge"=>$charge, ":company"=>$company, ":bio"=>$bio, ":img"=>$ponente, ":country"=>$country, ":linkedin"=>$linkedin, ":email"=>$email,":date"=>date("F j, Y, g:i a"),":prog"=>$porciones[0],":rol"=>$rol,"dateprog"=>$porciones[1], ":ctype"=>$ctype));

	$porciones=[''];

}
	
}else{
	
$porciones=[];	

$sql="INSERT INTO ponentes (TITLENAME, NAME, LASTNAME, CHARGE, COMPANY, BIO, IMG, COUNTRY, LINKEDIN, EMAIL, DATE, PROGRAMA, ROL, DATE_PROGRAM, COMMITTEETYPE) VALUES (:title,:name, :last, :charge, :company, :bio, :img, :country, :linkedin, :email, :date,:prog, :rol, :dateprog, :ctype)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":title"=>$title,":name"=>$name, ":last"=>$lastname, ":charge"=>$charge, ":company"=>$company, ":bio"=>$bio, ":img"=>$ponente, ":country"=>$country, ":linkedin"=>$linkedin, ":email"=>$email,":date"=>date("F j, Y, g:i a"),":prog"=>$porciones[0],":rol"=>$rol,"dateprog"=>$porciones[1], ":ctype"=>$ctype));

	
}


	





}else{

if($programa==""){

	$porciones=["",""];
$sql="INSERT INTO ponentes (TITLENAME, NAME, LASTNAME, CHARGE, COMPANY, BIO, IMG, COUNTRY, LINKEDIN, EMAIL, DATE, PROGRAMA, ROL, DATE_PROGRAM, COMMITTEETYPE) VALUES (:title, :name, :last, :charge, :company, :bio, :img, :country, :linkedin, :email, :date,:prog, :rol, :dateprog, :ctype)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":title"=>$title,":name"=>$name, ":last"=>$lastname, ":charge"=>$charge, ":company"=>$company, ":bio"=>$bio, ":img"=>$ponente, ":country"=>$country, ":linkedin"=>$linkedin, ":email"=>$email,":date"=>date("F j, Y, g:i a"),":prog"=>$porciones[0],":rol"=>$rol, "dateprog"=>$porciones[1], ":ctype"=>$ctype));
	
	}else{
	
	
foreach($programa as $elemento){

	$porciones = explode(",", $elemento);



$sql="INSERT INTO ponentes (TITLENAME, NAME, LASTNAME, CHARGE, COMPANY, BIO, IMG, COUNTRY, LINKEDIN, EMAIL, DATE, PROGRAMA, ROL, DATE_PROGRAM, COMMITTEETYPE) VALUES (:title, :name, :last, :charge, :company, :bio, :img, :country, :linkedin, :email, :date,:prog, :rol, :dateprog, :ctype)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":title"=>$title,":name"=>$name, ":last"=>$lastname, ":charge"=>$charge, ":company"=>$company, ":bio"=>$bio, ":img"=>$ponente, ":country"=>$country, ":linkedin"=>$linkedin, ":email"=>$email,":date"=>date("F j, Y, g:i a"),":prog"=>$porciones[0],":rol"=>$rol, "dateprog"=>$porciones[1], ":ctype"=>$ctype));

	$porciones=[''];

		



}
	
}


	

}



$sql4="SELECT * FROM ponentes ORDER BY LASTNAME ASC";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$ponentes[]=$fila4;

};





$file='../../info/ponentes.json';

file_put_contents($file,json_encode($ponentes));



if($fila!=0){

	echo "encontrado";

}else{

echo"success";	

}



?>