<?php 



include("../../connect/config.php");

$programa=[];

error_reporting(E_ALL ^ E_NOTICE);

$texto=$_POST['texto'];

$titulo=$_POST['titulo_p'];

$horai=$_POST['h_inicio'];

$horaf=$_POST['h_final'];

$id=0;

$fecha=$_POST['programa_fecha'];



$sql2="SELECT * FROM programa WHERE TITULO = :titulo AND DATE=:date";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":titulo"=>$titulo,":date"=>$fecha));

$fila=$resultado2->rowCount();



$sql3="SELECT * FROM programa";

$resultado3=$cnt->prepare($sql3);

$resultado3->execute();





do{



	$id=$id+1;

}while($fila2=$resultado3->fetch(PDO::FETCH_ASSOC));

	

	







if($_POST['id']){

	$id=$_POST['id'];

}



if($fila!=0){

	

$sql2="UPDATE programa SET ID = :id, TITULO = :titulo, TEXT=:text, HORAINICIO=:horai, HORAFINALIZAR=:horaf WHERE TITULO =:titulo2 AND DATE=:date";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":id"=>$id, ":titulo"=>$titulo,":text"=>$texto,":horai"=>$horai, ":horaf"=>$horaf,":titulo2"=>$titulo, ":date"=>$fecha));



	

}else{





$sql="INSERT INTO programa (ID, TITULO, TEXT, HORAINICIO, HORAFINALIZAR, DATE) VALUES(:id, :titulo, :text, :horai, :horaf, :date)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":id"=>$id, ":titulo"=>$titulo,":text"=>$texto,":horai"=>$horai,":horaf"=>$horaf,":date"=>$fecha));

	



}





$sql2="SELECT * FROM programa ORDER BY ID";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute();

while($fila=$resultado2->fetch(PDO::FETCH_ASSOC)){

	$programa[]=$fila;

}



$file='../../info/programa.json';

file_put_contents($file,json_encode($programa));

echo "success";

?>