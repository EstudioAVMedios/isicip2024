<?php 

include("../../connect/config.php");



$sql2="SELECT * FROM inicio";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute();

$fila=$resultado2->fetch(PDO::FETCH_ASSOC);





if($_POST['titulo']!=""){

	$titulo=$_POST['titulo'];

}else{

	$titulo=$fila['TITULO'];

}

if($_POST['texto']!=""){

	$texto=$_POST['texto'];

}else{

	$texto=$fila['TEXTO'];

}

if($_POST['firma']!=""){

	$firma=$_POST['firma'];

}else{

	$firma=$fila['FIRMA'];

}



$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/imagenes/";



$sql="UPDATE inicio SET TITULO=:titulo, TEXTO=:text, FIRMA=:firm, IMAGEN=:img";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":titulo"=>$titulo,":text"=>$texto,":firm"=>$firma,":img"=>$ruta."bienvenida_img.png"));



move_uploaded_file($_FILES['imagen1']['tmp_name'],$ruta."bienvenida_img.png");



$sql2="SELECT * FROM inicio";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute();

$fila=$resultado2->fetch(PDO::FETCH_ASSOC);



$file='../../info/inicio.json';

file_put_contents($file,json_encode($fila));

header('location:../index.php')

?>