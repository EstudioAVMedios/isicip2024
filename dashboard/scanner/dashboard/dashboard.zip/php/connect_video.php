<?php

include('../../connect/config.php');



$title=$_POST['titulo_v'];

$cont=$_POST['contenido_v'];

$speaker=$_POST['ponente_v'];

$h_d=$_POST['video_h'];

$m_d=$_POST['video_m'];

$vn=$_POST['video_name'];

$url=$_POST['url_v'];

$videos=[];

$video=$_FILES['video'];





$sql2="SELECT * FROM video WHERE TITLE=:titulo";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":titulo"=>$title));

$fila2=$resultado2->rowCount();



if($fila2!=0){

$sql3="DELETE FROM video WHERE TITLE=:titulo";

$resultado3=$cnt->prepare($sql3);

$resultado3->execute(array(":titulo"=>$title));

}





$video_name=base64_encode($title).".png";

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/videos/miniaturas/";

move_uploaded_file($_FILES['video']['tmp_name'],$ruta.$video_name);





foreach($speaker as $elemento){





$sql="INSERT INTO video (TITLE, CONTENT, SPEAKER,FILE, HDURATION, MDURATION, VIDEONAME, URL) VALUES (:title, :cont, :speaker,:file, :h_d, :m_d,:vn,:url)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":title"=>$title, ":cont"=>$cont, ":speaker"=>$elemento,":file"=>$video_name, ":h_d"=>$h_d,":m_d"=>$m_d,":vn"=>$vn,":url"=>$url));

	

}





$sql1="SELECT * FROM video";

$resultado1=$cnt->prepare($sql1);

$resultado1->execute();

while($fila=$resultado1->fetch(PDO::FETCH_ASSOC)){

	$videos[]=$fila;

}

	





$file='../../info/videos_carta.json';

file_put_contents($file,json_encode($videos));

echo "success";







?>