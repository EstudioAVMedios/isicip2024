<?php
/* Database connection start */
$servername = "localhost";
$username = "uenbnfxwlghx8";
$password = "57}k4[@@d2|4";
$dbname = "dbtd8uabdxcfa9";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
printf("Connect failed: %sn", mysqli_connect_error());
exit();
}
?>