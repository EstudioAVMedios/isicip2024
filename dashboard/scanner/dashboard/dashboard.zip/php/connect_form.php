<?php 

include("../../connect/config.php");



$sql2="SELECT * FROM event_";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute();

$fila=$resultado2->fetch(PDO::FETCH_ASSOC);

$genericos;



if($_POST['color']!="#000000"){

	$color=$_POST['color'];

}else{

	$color=$fila['COLOR'];

}

if($_POST['titulo']!=""){

	$titulo=$_POST['titulo'];

}else{

	$titulo=$fila['NAME'];

}





$header=$_FILES['header']['type'];

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/generica/";



$sql="UPDATE event_ SET NAME=:name, COLOR=:color, HEADER=:header, LOGO=:logo, FONDO=:fondo";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":name"=>$titulo,":color"=>$color,":header"=>$ruta."header.png",":logo"=>$ruta."logo.png",":fondo"=>$ruta."fondo.png"));



move_uploaded_file($_FILES['logo']['tmp_name'],$ruta."logo.png");

move_uploaded_file($_FILES['header']['tmp_name'],$ruta."header.png");

move_uploaded_file($_FILES['fondo']['tmp_name'],$ruta."fondo.png");



$sql2="SELECT * FROM event_";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute();

$fila=$resultado2->fetch(PDO::FETCH_ASSOC);



$file='../../info/generico.json';

file_put_contents($file,json_encode($fila));

header("location:../index.php");

?>