<?php 



include("../../connect/config.php");



$company=$_POST['empresa_sociedades'];

$url=$_POST['url_sociedades'];

$logo=$_FILES['logo_sociedades'];

$info=$_POST['info_sociedades'];

$sociedades=[];



if($company!="" and $url!="" and $info!=""){



$sql2="SELECT * FROM sociedades WHERE COMPANY = :com";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":com"=>$company));

$fila=$resultado2->rowCount();

$fila2=$resultado2->fetch(PDO::FETCH_ASSOC);





if($_FILES['logo_sociedades']){

	

$sociedad=base64_encode($company).".png";

$ruta=$_SERVER['DOCUMENT_ROOT']."/Imagenes/sociedades/";

move_uploaded_file($_FILES['logo_sociedades']['tmp_name'],$ruta.$sociedad);

	

}else if($fila2['IMG']==base64_encode($company).".png"){

	$sociedad=$fila2['IMG'];

}else{

$sociedad="user.png";	

}



if($fila!=0){

	

$sql3='DELETE FROM SOCIEDADES WHERE COMPANY=:com';

$resultado3=$cnt->prepare($sql3);

$resultado3->execute(array(":com"=>$company));







$sql="INSERT INTO SOCIEDADES (COMPANY, INFO, IMG, URL) VALUES (:com, :info, :img, :url)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":com"=>$company, ":info"=>$info, ":img"=>$sociedad, ":url"=>$url));



}else{

	$sql="INSERT INTO SOCIEDADES (COMPANY, INFO, IMG, URL) VALUES (:com, :info, :img, :url)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":com"=>$company, ":info"=>$info, ":img"=>$sociedad, ":url"=>$url));

}



$sql4="SELECT * FROM SOCIEDADES";

$resultado4=$cnt->prepare($sql4);

$resultado4->execute();

while($fila4=$resultado4->fetch(PDO::FETCH_ASSOC)){

    

$sociedades[]=$fila4;

};





$file='../../info/sociedades.json';

file_put_contents($file,json_encode($sociedades));



if($fila!=0){

	echo "encontrado";

}else{

echo "succes";	

}

	

}else{

	echo "empty";

}

?>