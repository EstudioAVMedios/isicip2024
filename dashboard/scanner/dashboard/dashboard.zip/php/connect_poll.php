<?php

include('../../connect/config.php');



$poll=$_POST['poll'];

$video=$_POST['video_poll'];

$type=$_POST['poll_type'];

$polls=[];

$answer=$_POST['answer'];

$display="none";

$time=$_POST['time'];



$sql2="SELECT * FROM poll WHERE POLL=:poll";

$resultado2=$cnt->prepare($sql2);

$resultado2->execute(array(":poll"=>$poll));

$fila2=$resultado2->rowCount();



if($fila2!=0){

$sql3="DELETE FROM poll WHERE POLL=:poll";

$resultado3=$cnt->prepare($sql3);

$resultado3->execute(array(":poll"=>$poll));

}



foreach($answer as $elemento){





$sql="INSERT INTO poll (POLL, ANSWER, TYPE, VIDEO, DISPLAY,TIME) VALUES (:poll, :ans, :type, :video, :dis, :time)";

$resultado=$cnt->prepare($sql);

$resultado->execute(array(":poll"=>$poll, ":ans"=>$elemento, ":type"=>$type,":video"=>$video,":dis"=>$display, ":time"=>$time));

	

}





$sql1="SELECT * FROM poll";

$resultado1=$cnt->prepare($sql1);

$resultado1->execute();

while($fila=$resultado1->fetch(PDO::FETCH_ASSOC)){

	$polls[]=$fila;

}

	





$file='../../info/poll.json';

file_put_contents($file,json_encode($polls));

echo "success";







?>