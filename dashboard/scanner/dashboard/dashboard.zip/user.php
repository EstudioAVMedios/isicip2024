<?php


session_start();

if ( $_GET[ 'cerrar' ] == true ) {
    $_SESSION[ 'id_admin_login' ] = "";

}
include( "encode.php" );

header( "Content-Type: text/html;charset=utf-8" );

if ( !empty( $_SESSION[ 'id_admin_login' ] ) ) {

    include( "../php/config.php" );
    $usuarios2 = [];
    $usuarios = [];
    $activos = [];
    $columnas = [];
    $sql3 = "SELECT * FROM columns";
    $resultado4 = $cnt->prepare( $sql3 );
    $resultado4->execute();
    while ( $fila4 = $resultado4->fetch() ) {
        $columnas[] = $fila4;
    };

    $sql3 = "SELECT * FROM form";

    $resultado3 = $cnt->prepare( $sql3 );

    $resultado3->execute();

    while ( $fila3 = $resultado3->fetch( PDO::FETCH_ASSOC ) ) {
        if ( $fila3[ 'TYPE' ] == 1 ) {
            $activoscg[] = $fila3;
        } else if ( $fila3[ 'TYPE' ] == 2 ) {
            $usuarioscs[] = $fila3;
        } else {
            $usuarioso[] = $fila3;
        }
        $usuarios2[] = $fila3;
    }
    if ( $_GET[ 'search' ] != "" ) {

        $sql = "SELECT * FROM form WHERE EMAIL LIKE '%" . $_GET[ 'search' ] . "%' OR NAME LIKE '%" . $_GET[ 'search' ] . "%'";
        $resultado = $cnt->prepare( $sql );
        $resultado->execute();

        while ( $fila = $resultado->fetch( PDO::FETCH_ASSOC ) ) {

            $usuarios[] = $fila;

        }

    } else {

        $sql2 = "SELECT * FROM form";

        $resultado2 = $cnt->prepare( $sql2 );

        $resultado2->execute();

        while ( $fila2 = $resultado2->fetch( PDO::FETCH_ASSOC ) ) {
            $usuarios[] = $fila2;

        }

    }


} else {
    session_destroy();
    header( "location:access.php" );
}

?>

<!doctype html>

<html lang="en">
<head>
<title>Dashboard INICIO</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="Imagenes/logo_white.png" type="image/x-icon">
<!---------------bloqueo de cache------------------------------------>

<meta http-equiv="Expires" content="0">
<meta http-equiv="Last-Modified" content="0">
<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
<meta http-equiv="Pragma" content="no-cache">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/TableExport/5.2.0/css/tableexport.css" integrity="sha512-+m+NCQG6uttXsLjwxHTUdhov99LW3TSFEiM2LSFMwfOePszb2as348/96cCBG35mOK+3Gp4P0EQRWpKLZfGTnA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/icon/iconfonts.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<body>
<button class="ir-arriba"  javascript:void(0) title="Volver arriba"> <span class="fa-stack"> <i class="fa fa-circle fa-stack-2x"></i> <i class="fa fa-arrow-up fa-stack-1x fa-inverse"></i> </span> </button>
<div class="d-block">
  <nav class="navbar navbar-expand-lg navbar-light position-fixed w-100 shadow" style="z-index: 3;top:0px; background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">
    <h1><a href="index.html" class="logo"><img src="Imagenes/logo_white.png" class="me-auto px-5 mx-5" style='height: 70px'></a></h1>
    <div class="d-flex ms-auto" id="navbarNavDropdown">
      <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
      <ul class="navbar-nav ms-auto px-5">
        <!-- <li class="nav-item"> <a class="nav-link  text-white" href="index.php"><i class="fas fa-tools"></i> Panel de Administración</a> </li>-->
        <li class="nav-item"> <a class="nav-link  text-white text-dark" href="user.php"><i class="icon-users"></i> Users</a> </li>
        <li class="nav-item"> <a class="nav-link  text-white text-dark" href="user.php?cerrar=true"><i class="icon-power"></i> Salir</a> </li>
      </ul>
    </div>
  </nav>
  <nav class="navbar navbar-expand-lg navbar-light bg-light position-fixed w-100 shadow" style="top:90px;height: 70px;z-index: 2">
    <div class="container">
      <div class='d-flex me-auto'>
        <h6 class="mx-3"><b>REGISTRADOS</b> <span class="badge bg-dark"><?php echo count($usuarios2)?></span></h6>
        <h6 class="mx-3">C.GENERAL <span class="badge bg-dark"><?php echo count($activoscg)?></span></h6>
        <h6 class="mx-3">C.SOCIO SEC <span class="badge bg-dark"><?php echo count($usuarioscs)?></span></h6>
        <h6 class="mx-3">C.ONLINE <span class="badge bg-dark"><?php echo count($usuarioso)?></span></h6>
        <!--<h5 class="mx-4">CÓDIGOS <span class="badge bg-dark"><?php /*echo count($usuarios)-count($tpv)-count($bank)*/?></span></h5>--> 
      </div>
      <div class="d-flex ms-auto" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto mt-2">
          <li> <a href = "#"  class="ov-btn-slide-left mx-2" data-bs-toggle='modal' data-bs-target='#exampleModalimport'><i class="icon-cloud-upload-alt" style="transform: rotate(180deg)"></i> Importar usuarios</a></li>
          <li> <a  href='#' class="ov-btn-slide-left mx-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop2"><i class="icon-cloud-download-alt"></i> Exportar usuarios</a></li>
          <li> <a href = "user.php" class="ov-btn-slide-left mx-2"><i class="icon-users"></i>Usuarios</a> </li>
          <li> <a href = "user.php" class="ov-btn-slide-left mx-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop3"><img src='Imagenes/user-plus.png' style="width: 25px"> </a></li>
        </ul>
      </div>
    </div>
  </nav>
</div>
<div id="total_users" style="z-index: 0;margin-top:200px" class="d-block">
  <div class="mt-5 m-auto" style="width: 90%">
    <form class="row g-3 me-auto d-inline-block" action="<?php echo $_SERVER['PHP_SELF']?>" style="width: 90%">
      <div class="col-auto d-inline-block">
        <label for="inputPassword2" class="visually-hidden">Correo electrónico</label>
        <input type="text" class="form-control border" id="inputPassword2" placeholder="Correo electrónico" name="search">
      </div>
      <div class="col-auto mb-3 d-inline-block"> 
        <!--<button type="submit" class="btn btn-dark mb-3"><i class="fas fa-search"></i> Buscar</button>-->
        <button href = "user.php" class="ov-btn-slide-left "><i class="icon-search"></i> Buscar </button>
      </div>
    </form>
    <div class="btn-group dropstart me-auto d-inline-block" style="z-index: 1">
      <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> Ajustes </button>
      <ul class="dropdown-menu">
        <form class="w-100" id="form_filter">
          <?php
          foreach ( $columnas as $elemento ) {

              if ( $elemento[ 'ESTADO' ] == 1 ) {
                  echo "<li class='text-dark px-3 mx-2'><div class='form-check'><input  class='form-check-input filterlink p-2' type='checkbox' checked  value='" . $elemento[ 'COLUMNS' ] . "' id='flexCheckDefault'><label class='form-check-label' for='flexCheckDefault'>" . $elemento[ 'COLUMNS' ] . "</label></div></li>";
              } else {
                  echo "<li class='text-dark px-3 mx-2'><div class='form-check'><input  class='form-check-input filterlink p-2' type='checkbox' value='" . $elemento[ 'COLUMNS' ] . "' id='flexCheckDefault'><label class='form-check-label' for='flexCheckDefault'>" . $elemento[ 'COLUMNS' ] . "</label></div></li>";
              }

          }
          ?>
          <button type="button" class="ov-btn-slide-left m-3 w-75" id="sendfilter">Enviar</button>
        </form>
        
        <!-- Dropdown menu links -->
      </ul>
    </div>
    <table class="table table-hover m-auto" id="data_table" style="font-size: 12px">
      <thead class="m-auto">
        <tr>
          <?php
          /*******************************************************CREAR TABLA***************************************************************************************/
          $cuota = 0;
          foreach ( $columnas as $elemento ) {
              if ( $elemento[ 'ESTADO' ] == 1 ) {
                  if ( $elemento[ 'COLUMNS' ] == "TYPE" ) {
                      echo "<th scope='col'><strong>" . $elemento[ 'COLUMNS' ] . "</strong></th><th scope='col'><strong>CUOTA</strong></th>";
                  } else {
                      echo "<th scope='col'><strong>" . $elemento[ 'COLUMNS' ] . "</strong></th>";
                  }
              }

          }
          echo "<th scope='col'><strong>ESTADO</strong></th><th scope='col'><strong>DATOS FACTURA</strong></th><th scope='col'><strong>EDITAR</strong></th><th scope='col'><strong>ELIMINAR</strong></th>";
          ?>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ( $usuarios as $elemento ) {
            if ( $elemento[ 'STATE' ] == 1 ) {

                $estado = "<span class=' bg-success  text-white p-2 rounded' style='cursor:auto'>ACTIVO</span>";
            } else {
                if ( $elemento[ 'F_PAGO' ] == "TRANSF" ) {
                    $estado = "<p hidden>" . $elemento[ 'ID' ] . "</p><span class=' bg-danger text-white activar p-2 rounded' data-bs-toggle='modal' data-bs-target='#exampleModal2' style='cursor:pointer'>Activar</span>";
                } else {
                    $estado = "<p hidden>" . $elemento[ 'ID' ] . "</p><span class='bg-warning text-white p-2 rounded' style='cursor:default'>PENDIENTE</span>";
                }

            }

            if ( $elemento[ 'IMPORT' ] == 0 ) {
                $fact_data = "<p hidden >" . $elemento[ 'ID' ] . "</p><span class='btn-dark p-2 rounded fact_data'  data-bs-toggle='modal' data-bs-target='#staticBackdrop' style='cursor: pointer;text-align:center'><i class='icon-eye'></i></span>";
            } else {
                $fact_data = "<span class=' bg-success  text-white p-2 rounded' style='cursor:auto'>IMPORTADO</span>";
            }


            /******************************RELLENAR COLUMNAS*****************************/
            echo "<tr>";
            foreach ( $columnas as $elemento2 ) {


                if ( $elemento2[ 'ESTADO' ] == 1 ) {


                    if ( $elemento2[ 'COLUMNS' ] == "EMAIL" ) {
                        echo "<td class='email'>" . $elemento[ $elemento2[ 'COLUMNS' ] ] . "</td>";
                    } else {


                        if ( $elemento2[ 'COLUMNS' ] == "TYPE" ) {
                            if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 1 ) {
                                echo "<td class=''>280,00</td><td class=''>Cuota General</td>";

                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 2 ) {
                                echo "<td class=''>190,00</td><td class=''>Cuota Socio SEC</td>";

                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 3 ) {
                                echo "<td class=''>120,00</td><td class=''>Cuota Online</td>";

                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 4 ) {
                                echo "<td class=''>0,00</td><td class=''>Ponente</td>";

                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 5 ) {
                                echo "<td class=''>0,00</td><td class=''>Buyer</td>";

                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 6 ) {
                                echo "<td class=''>0,00</td><td class=''>Patrocinador</td>";

                            }

                        } else {
                            if ( $elemento2[ 'COLUMNS' ] == "F_PAGO" ) {
                                if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == "TRANSF" ) {
                                    echo "<td class=''>TRANSF</td>";
                                } else {
                                    echo "<td class=''>TPV</td>";
                                }
                            } else {
                                echo "<td class=''>" . $elemento[ $elemento2[ 'COLUMNS' ] ] . "</td>";
                            }


                        }


                    }


                }


            }

            echo "<td>" . $estado . "</td><td class='text-center'>" . $fact_data . "</td><td class='text-center'><p hidden>" . $elemento[ 'ID' ] . "</p><i class='icon-pencil-alt elicon edit' data-bs-toggle='modal' data-bs-target='#staticBackdrop4'></i></td><td class='text-center'><i class='icon-burn elicon' style='font-size: 20px;cursor: pointer' data-bs-toggle='modal' data-bs-target='#exampleModal'></i></td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
<!----------------------------------MODAL---------------------------------------------->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" >
  <div class="modal-dialog modal-md"style="z-index:5">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Datos de Facturación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <h5><strong>NIF/CIF: </strong><span id="nif_modal"></span></h5>
          <h5><strong>Razón Social: </strong><span id="rs_modal"></span></h5>
          <h5><strong>Dirección: </strong><span id="bill_modal"></span></h5>
          <h5><strong>Provincia: </strong><span id="prov_modal"></span></h5>
          <h5><strong>Población: </strong><span id="pobla_modal"></span></h5>
          <h5><strong>Email: </strong><span id="email_modal"></span></h5>
          <h5><strong>Código Postal: </strong><span id="cp_modal"></span></h5>
          <h5><strong>Teléfono: </strong><span id="tel_modal"></span></h5>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal YES NO ACVTIVAR -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Usuario</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body"> ¿Estás segur@ de que deseas eliminar a este usuario? <br>
        <span class="badge bg-dark p-1" id='modal_delete'>EMAIL</span></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary me-auto" data-bs-dismiss="modal"> Volver</button>
        <button type="button" class="btn " id='send_delete'  style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">Eliminar</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModalimport" tabindex="-1" aria-labelledby="exampleModalLabelimport" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabelimport">Subir lista</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body ">
        <form method="POST" enctype="multipart/form-data" id="import-form" class="text-start">
          <div class="file-input text-start">
            <div class="mb-3">
              <label for="formFile" class="form-label">Elegir Archivo Excel</label>
              <input class="form-control file-input__input" type="file" id="file-input" name="dataClientexl">
            </div>
            <!-- <label class="file-input__label" for="file-input"> <i class="zmdi zmdi-upload zmdi-hc-2x"></i> <span></span></label>
            <input  type="file" name="dataCliente" id="file-input" class="file-input__input"/>-->
            <label for="formFile" class="form-label">¿Qué acciones desea realizar con los usuarios que ya existen?</label>
            <div class="form-check">
              <input class="form-check-input" type="radio"  value='1' name="action" id="radio1" checked>
              <label class="form-check-label" for="radio1"> Saltar al siguiente </label>
            </div>
            <div class="form-check">
              <input class="form-check-input " type="radio" value='2' name="action" id="radio2">
              <label class="form-check-label" for="radio2"> Actualizar datos </label>
            </div>
          </div>
          <div class="modal-footer text-end mt-5"> 
            <!--<input type="button" name="subir" class="btn-enviar btn" value="Subir Excel"  style='background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);'/>--> 
            <a href='../assets/archivos/dataClientesxl.xlsx' download='dataClientesxl' type="button" class="btn btn-secondary me-auto" > Descargar plantilla</a>
            <button type="button" class="btn btn-enviar" style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);" id='subir_excel'>Subir Excel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel2">Activar Usuario</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body"> ¿Estás segur@ de que deseas activar a este usuario? <br>
        <span class="badge bg-dark p-1" id='modal_email'>EMAIL</span> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary me-auto" data-bs-dismiss="modal"> Volver</button>
        <button type="button" class="btn" id='send_active' style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">Activar</button>
      </div>
    </div>
  </div>
</div>
<!------MODAL EXPORT------------------> 
<!-- Button trigger modal -->
<div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdrop2Label" aria-hidden="true" >
  <div class="modal-dialog modal-md"style="z-index:5">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdrop2Label">Datos de Facturación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container">
          <h6>¿Desea agregar los datos de facturación al archivo?</h6>
        </div>
      </div>
      <div class="modal-footer"> <a  href='export2.php' type="button" class="btn btn-secondary export  me-auto px-5" >No</a> <a  href='export.php' type="button" class="btn export px-5" style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">Si</a> </div>
    </div>
  </div>
</div>
<!------NEW USER------------------> 
<!-- Button trigger modal -->
<div class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdrop3Label" aria-hidden="true" >
  <div class="modal-dialog modal-xl"style="z-index:5">
    <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="staticBackdrop3Label">Nuevo usuario</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
    <div class="container px-4">
    <form id="contactform" method="post">
      <fieldset>
        <div class="d-block w-100">
          <h4 class=" p-2" >Cuota</h4>
        </div>
        <!-- form two columns start -->
        <div class="row g-3 needs-validation">
        <div class="col-4 ">
          <div class="m-pago2" >
            <p hidden>1</p>
            Cuota General</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2">
            <p hidden>2</p>
            Cuota Socio SEC</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2" >
            <p hidden>3</p>
            Cuota Online</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2" >
            <p hidden>4</p>
            Ponente</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2" >
            <p hidden>5</p>
            Buyer</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2" >
            <p hidden>6</p>
            Patrocinador</div>
        </div>
        <div class="d-block w-100">
          <h4 class=" p-2" >Método de Pago</h4>
        </div>
        <!-- form two columns start -->
        <div class="row g-3 needs-validation">
        <div class="col-6 ">
          <div class="m-pago" >
            <p hidden>TPV</p>
            Tarjeta de Débito o Crédito</div>
        </div>
        <div class="col-6 ">
          <div class="m-pago" >
            <p hidden>TRANSF</p>
            Transferencia Bancaria</div>
        </div>
        <div class="d-block w-100">
          <h4 class=" p-2" >Datos Personales</h4>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Nombre</span></p>
          <input name="name"  class="form-control border required text" type="text" placeholder="John">
        </div>
        <div class="col-md-6">
          <label class="form-label"> <span class="dtr-form-subtext">Apellidos</span></label>
          <input name="surname"  class="form-control border required text" type="text" placeholder="Martínez Pérez ">
        </div>
        <div class="col-md-6">
          <?php if($price!=3){?>
          <p class="form-label"> <span class="dtr-form-subtext">DNI/NIE</span></p>
          <input name="dni"  type="text" class='form-control border required text' placeholder="00523821F" maxlength="9" id="dni">
          <?php }else{ ?>
          <p class="form-label"> <span class="dtr-form-subtext">Pasaporte</span></p>
          <input name="dni"  type="text" class='form-control border required text' placeholder="I673608">
          <?php }; ?>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Email</span></p>
          <input name="email"  class="form-control border required email" type="email" placeholder="john@example.com">
        </div>
        <div class="col-md-12" style="display: none" id="socsec">
          <p class="form-label"> <span class="dtr-form-subtext">No de Socio SEC</span>
            <input name="nosec"  type="text" class='form-control border' placeholder="00523821F" maxlength="9">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Centro de Trabajo</span></p>
          <input name="trabajo"  class="form-control border" type="text required text" placeholder="Hospital...">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Especialidad</span> </p>
          <input name="espe"  class="form-control border" type="text required text" placeholder="Cardiología">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Cargo</span> </p>
          <input name="cargo"  type="text"  class='form-control border required text' placeholder="Jefe del área de cardiología...">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Teléfono</span> </p>
          <input name="tel"  class="form-control border" type="tel required text" placeholder="+34715127859">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span >Contraseña</span> </p>
          <input name="pass"  class="form-control border required text" type="password" id='pass'>
          </p>
          <div class="w-100" style="text-align: right"><a style="text-align: right; margin-top: -95px!important; margin-left: auto; cursor: pointer;position: relative" class="btn" id="show">Mostrar</a></div>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span>Repetir contraseña</span> </p>
          <input name="pass2"  class="form-control border required text" type="password" id='pass1'>
          <div class="w-100" style="text-align: right"><a style="text-align: right; margin-top: -65px!important; margin-left: auto; cursor: pointer;position: relative" class="btn" id="show1">Mostrar</a></div>
        </div>
        <div class="d-block w-100">
          <h4 class=" p-2" >Datos de Facturación</h4>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">NIF/CIF</span> </p>
          <input name="nif"  class="form-control border required text" type="text" placeholder="6994785X">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Razón social</span> </p>
          <input name="rsocial"  class='form-control border required text' type="text"  placeholder="AV Medios S.L">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Dirección</span> </p>
          <input name="baddress"  class="form-control border required text" type="text" placeholder="Calle x, 12">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Código Postal</span> </p>
          <input name="cp"  class="form-control border required text" type="text" placeholder="28005">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Población</span> </p>
          <input name="bpobla"  class="form-control border required text" type="text" placeholder="Madrid">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Provincia</span> </p>
          <input name="bprov"  class="form-control border required text" type="text" placeholder="Madrid">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Email</span> </p>
          <input name="bemail"  class="required email form-control border" type="email" placeholder="john@example.com">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Teléfono</span> </p>
          <input name="btel"  class="form-control border required text required text" type="tel" placeholder="+34789458637">
        </div>
        <div class="col-md-12">
          <button type="submit" class="btn p-3 w-100" style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">Enviar</button>
        </div>
        <div id="formalert"></div>
        <div id="result"></div>
      </fieldset>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary me-auto px-5" data-bs-dismiss="modal">Cerrar</button>
      </div>
      </div>
    </form>
  </div>
</div>

<!------UPDATE USER------------------> 
<!-- Button trigger modal -->
<div class="modal fade" id="staticBackdrop4" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdrop4Label" aria-hidden="true" >
  <div class="modal-dialog modal-xl"style="z-index:5">
    <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="staticBackdrop4Label">Editar Datos</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
    <div class="container px-4">
    <form id="contactform2" method="post">
      <fieldset>
        <div class="d-block w-100">
          <h4 class=" p-2" >Cuota</h4>
        </div>
        <!-- form two columns start -->
        <div class="row g-3 needs-validation">
        <div class="col-4">
          <div class="m-pago2" id='cuota1'>
            <p hidden>1</p>
            Cuota General</div>
        </div>
        <div class="col-4 ">
          <div class="m-pago2"  id='cuota2'>
            <p hidden>2</p>
            Cuota Socio SEC</div>
        </div>
        <div class="col-4 " >
          <div class="m-pago2" id='cuota3'>
            <p hidden>3</p>
            Cuota Online</div>
        </div>
        <div class="col-4 " >
          <div class="m-pago2" id='cuota4'>
            <p hidden>4</p>
            Ponente</div>
        </div>
        <div class="col-4 " >
          <div class="m-pago2" id='cuota5'>
            <p hidden>5</p>
           Buyer</div>
        </div>
        <div class="col-4 " >
          <div class="m-pago2" id='cuota6'>
            <p hidden>6</p>
           Patrocinador</div>
        </div>
        <div class="d-block w-100">
          <h4 class=" p-2" >Método de Pago</h4>
        </div>
        <!-- form two columns start -->
        <div class="row g-3 needs-validation">
          <div class="col-6 ">
            <div class="m-pago" id='tarjeta'>
              <p hidden>TPV</p>
              Tarjeta de Débito o Crédito</div>
          </div>
          <div class="col-6 ">
            <div class="m-pago" id='banco'>
              <p hidden>TRANSF</p>
              Transferencia Bancaria</div>
          </div>
          <div class="d-block w-100">
            <h4 class=" p-2" >Datos Personales</h4>
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Nombre</span></p>
            <input name="name"  class="form-control border required text" type="text" placeholder="John" id="nom">
          </div>
          <div class="col-md-6">
            <label class="form-label"> <span class="dtr-form-subtext">Apellidos</span></label>
            <input name="surname"  class="form-control border required text" type="text" placeholder="Martínez Pérez" id="ape2">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Docuemnto de Identidad</span></p>
            <input name="dni"  type="text" class='form-control border required text' placeholder="00523821F" maxlength="9" id="dni2">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Email</span></p>
            <input name="email"  class="form-control border required email" type="email" placeholder="john@example.com" id="email2">
          </div>
          <div class="col-md-12"  id="socsec2">
            <p class="form-label"> <span class="dtr-form-subtext">No de Socio SEC</span>
              <input name="nosec"  type="text" class='form-control border' placeholder="00523821F" maxlength="9" id="sec2">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Centro de Trabajo</span></p>
            <input name="trabajo"  class="form-control border" type="text required text" placeholder="Hospital..." id="ctrab">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Especialidad</span> </p>
            <input name="espe"  class="form-control border" type="text required text" placeholder="Cardiología" id="espe">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Cargo</span> </p>
            <input name="cargo"  type="text"  class='form-control border required text' placeholder="Jefe del área de cardiología..." id="charge">
          </div>
          <div class="col-md-6">
            <p class="form-label"> <span class="dtr-form-subtext">Teléfono</span> </p>
            <input name="tel"  class="form-control border" type="tel required text" placeholder="+34715127859" id="tele">
          </div>
          <!-- <div class="col-md-6">
          <p class="form-label"> <span >Contraseña</span> </p>
          <input name="pass"  class="form-control border required text" type="password" id='pass2'>
          </p>
          <div class="w-100" style="text-align: right"><a style="text-align: right; margin-top: -95px!important; margin-left: auto; cursor: pointer;position: relative" class="btn" id="show">Mostrar</a></div>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span>Repetir contraseña</span> </p>
          <input name="pass2"  class="form-control border required text" type="password" id='pass3'>
          <div class="w-100" style="text-align: right"><a style="text-align: right; margin-top: -65px!important; margin-left: auto; cursor: pointer;position: relative" class="btn" id="show1">Mostrar</a></div>--> 
        </div>
        <div class="d-block w-100">
          <h4 class=" p-2" >Datos de Facturación</h4>
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">NIF/CIF</span> </p>
          <input name="nif"  class="form-control border required text" type="text" placeholder="6994785X" id="cif">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Razón social</span> </p>
          <input name="rsocial"  class='form-control border required text' type="text"  placeholder="AV Medios S.L" id="rsocial">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Dirección</span> </p>
          <input name="baddress"  class="form-control border required text" type="text" placeholder="Calle x, 12" id="address">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Código Postal</span> </p>
          <input name="cp"  class="form-control border required text" type="text" placeholder="28005" id="cpostal">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Población</span> </p>
          <input name="bpobla"  class="form-control border required text" type="text" placeholder="Madrid" id="pobla">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Provincia</span> </p>
          <input name="bprov"  class="form-control border required text" type="text" placeholder="Madrid" id="prov">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Email</span> </p>
          <input name="bemail"  class="required email form-control border" type="email" placeholder="john@example.com" id="email3">
        </div>
        <div class="col-md-6">
          <p class="form-label"> <span class="dtr-form-subtext">Teléfono</span> </p>
          <input name="btel"  class="form-control border required text required text" type="tel" placeholder="+34789458637" id="tele2">
        </div>
        <div class="col-md-12">
          <button id="update" class="btn p-3 w-100" style="background: linear-gradient(45deg, rgba(50,225,159,1) 32%, rgba(229,255,71,1) 100%);">Actualizar</button>
        </div>
        <div id="formalert2"></div>
        <div id="result2"></div>
      </fieldset>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary me-auto px-5" data-bs-dismiss="modal">Cerrar</button>
      </div>
      </div>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script> 
<script src="js/plugins.js"></script> 
<script src="js/dashboard_user.js"></script>
</body>
</html>