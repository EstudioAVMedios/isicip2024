<?php

session_start();
header( 'Content-type: application/vnd.ms-excel' );

header( "Content-Disposition: attachment; filename=FAM_" . date( "m.d.y" ) . ".xls" ); //Indica el nombre del archivo resultante

header( "Pragma: no-cache" );

header( "Expires: 0" );

if ( !empty( $_SESSION[ 'id_admin_login' ] ) ) {

} else {

  session_destroy();

  header( "location:access.php" );

}


include( "../php/config.php" );


date_default_timezone_set( "Europe/Madrid" );


$sql2 = "SELECT * FROM form";

$resultado2 = $cnt->prepare( $sql2 );

$resultado2->execute();

while ( $fila2 = $resultado2->fetch( PDO::FETCH_ASSOC ) ) {


  $usuarios[] = $fila2;


}
$sql5 = "SELECT * FROM form2";

$resultado5 = $cnt->prepare( $sql5 );

$resultado5->execute();

while ( $fila5 = $resultado5->fetch( PDO::FETCH_ASSOC ) ) {


  $usuariosfact[] = $fila5;


}

$dfact=[1=>"NIF",2=>"RAZON_S",3=>"BILL_ADDRESS",4=>"PROVINCIA",5=>"POBLACION",6=>"EMAIL",7=>"C_POSTAL",8=>"TEL"];






$sql3 = "SELECT * FROM columns";
$resultado4 = $cnt->prepare( $sql3 );
$resultado4->execute();
while ( $fila4 = $resultado4->fetch() ) {
  $columnas[] = $fila4;
};



/*header( "location:user.php" );*/


?>
<html lang="en">
<head>
<title>Dashboard INICIO</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!---------------bloqueo de cache------------------------------------>

<meta http-equiv="Expires" content="0">
<meta http-equiv="Last-Modified" content="0">
<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
<meta http-equiv="Pragma" content="no-cache">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>

<table class="table">
  <thead class="m-auto">
    <tr>
      <?php
      /*******************************************************CREAR TABLA***************************************************************************************/
      foreach ( $columnas as $elemento ) {
        if ( $elemento[ 'ESTADO' ] == 1 ) {
if($elemento[ 'COLUMNS' ]=="TYPE"){
	 echo "<th scope='col'><strong>" . $elemento[ 'COLUMNS' ] . "</strong></th><th scope='col'><strong>CUOTA</strong></th>";
}else{
	 echo "<th scope='col'><strong>" . $elemento[ 'COLUMNS' ] . "</strong></th>";
}
         
        }

      }
for($i=1;$i<9;$i++){
	echo "<th scope='col'>". $dfact[$i] ."</th>";
}
      ?>
    </tr>
  </thead>
  <tbody>
    <?php
    foreach ( $usuarios as $elemento ) {

      /**********************************************************************************RELLENAR COLUMNAS**********************************************************/
      echo "<tr>";
         foreach ( $columnas as $elemento2 ) {


                if ( $elemento2[ 'ESTADO' ] == 1 ) {


                    if ( $elemento2[ 'COLUMNS' ] == "EMAIL" ) {
                        echo "<td class='email'>" . $elemento[ $elemento2[ 'COLUMNS' ] ] . "</td>";
                    } else {


                        if ( $elemento2[ 'COLUMNS' ] == "TYPE" ) {
                            if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 1 ) {
                                echo "<td class=''>280,00</td><td class=''>Cuota General</td>";
								
                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 2 ) {
                                echo "<td class=''>190,00</td><td class=''>Cuota Socio SEC</td>";
								
                            } else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 3 ) {
                                echo "<td class=''>120,00</td><td class=''>Cuota Online</td>";
							
                            }else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 4 ) {
                                echo "<td class=''>0,00</td><td class=''>Ponente</td>";
							
                            }else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 5 ) {
                                echo "<td class=''>0,00</td><td class=''>Buyer</td>";
							
                            }else if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == 6 ) {
                                echo "<td class=''>0,00</td><td class=''>Patrocinador</td>";
							
                            }

                        } else {
                            if ( $elemento2[ 'COLUMNS' ] == "F_PAGO" ) {
                                if ( $elemento[ $elemento2[ 'COLUMNS' ] ] == "bank" ) {
                                    echo "<td class=''>TRANSF</td>";
                                } else {
                                    echo "<td class=''>TPV</td>";
                                }
                            } else {
                                echo "<td class=''>" . $elemento[ $elemento2[ 'COLUMNS' ] ] . "</td>";

                            }


                        }


                    }


                }

            }
										foreach($usuariosfact as $fact){
	if($fact['USER_ID']==$elemento['ID']){
		echo "<td class=''>". $fact['NIF'] ."</td><td class=''>". $fact['RAZON_S'] ."</td><td class=''>". $fact['BILL_ADDRESS'] ."</td><td class=''>". $fact['PROVINCIA'] ."</td><td class=''>". $fact['POBLACION'] ."</td><td class=''>". $fact['EMAIL'] ."</td><td class=''>". $fact['C_POSTAL'] ."</td><td class=''>". $fact['TEL'] ."</td>";
	}
	
}
	
	}
      ?>
  </tbody>
</table>
<?php /*header("location:user.php")*/?>
